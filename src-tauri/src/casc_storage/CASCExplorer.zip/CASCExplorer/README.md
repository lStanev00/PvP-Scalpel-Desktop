CASCExplorer
============

You can download compiled binaries [here][Binaries].

Make sure to edit path to wow folder in config file before use.

[Donate][Donate] to support developer!

[Binaries]: https://github.com/WoW-Tools/CASCExplorer/releases
[Donate]: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CFDMAA6ELV2G8

# Build instructions
First grab the code using git:

```
git clone https://github.com/WoW-Tools/CASCExplorer.git
cd CASCExplorer
git submodule update --init --recursive
```

Use Visual Studio 2017 15.7.0 or higher to build it once you have all dependencies.
